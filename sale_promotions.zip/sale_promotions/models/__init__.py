'''
Models for Sales Promotions
'''