# -*- coding: utf-8 -*-
from osv import fields, osv
import time
from datetime import datetime

#----------------------------------------------------------
# School location
#----------------------------------------------------------
class product_school_location(osv.osv):
    _name = "product.school.location"
    _description = "Product school location"
    _columns = {
        'name': fields.char('Name', size=64),
        'note': fields.text('Note'),
        'school_ids': fields.one2many('product.product', 'location_id', 'Schools'),
    }
product_school_location()

#----------------------------------------------------------
# School program
#----------------------------------------------------------

class product_school_program(osv.osv):
    _name = "product.school.program"
    _description = "Product school program"
    _columns = {
        'name': fields.char('Name', size=64),
        'note': fields.text('Note'),
        'school_ids': fields.one2many('product.product', 'program_id', 'Schools'),
    }
product_school_program()

#----------------------------------------------------------
# School
#----------------------------------------------------------

class product_product(osv.osv):
    _name = "product.product"
    _inherit = "product.product"
    _description = "School module"
    _columns = {
		#'name': fields.char('Name', size=64),
		'year': fields.date('Year'),
        'session': fields.char('Session', size=64),
		#'default_code' : fields.char('Reference', size=64, select=True),
        'currency_id': fields.many2one('res.currency', 'Currency', required=True, readonly=True, states={'draft':[('readonly',False)]}),
		'start_date': fields.date('Start Date', size=30, required=True),
		'end_date': fields.date('End Date', size=30, required=True),
        'location_id': fields.many2one('product.school.location', 'Location'),
        'program_id': fields.many2one('product.school.program', 'Program'),
        'registration_fee': fields.integer('Registration Fees', required=True, help="Apply only if applicant book more than 5 months in advance."),
        'tuition_student': fields.integer('Tuition', required=True, help="Tuition for Student under 25."),
        'tuition_professional': fields.integer('Tuition', required=True, help="Tuition for professional"),
        'early_bird_date': fields.date('Early bird date', size=30, required=True),
        'early_bird_discount': fields.integer('Early Bird Discount', required=True),
        'accomodation_student_sr': fields.integer('Single room', required=True),
        'accomodation_student_dr': fields.integer('Double room', required=True),
        'accomodation_professional_sr': fields.integer('Single room', required=True),
        'accomodation_professional_dr': fields.integer('Double room', required=True),  
        'extension_weeks': fields.integer('Extension weeks', required=False, help="Maximum number of additional weeks"),
        'extension_weeks_tuition': fields.integer('extension weeks tuition', required=False, help="Maximum number of additional weeks"),            
        'extension_weeks_sr': fields.integer('Single room', required=False),
        'extension_weeks_dr': fields.integer('Double room', required=False),
        'extension_weeks_full_board': fields.integer('Full board', required=False),        
        'additional_nights_sr': fields.integer('Single room', required=False),
        'additional_nights_dr': fields.integer('Double room', required=False),          
        'full_board': fields.integer('Full Board', required=False),
        'airport': fields.integer('Airport pick up', required=False, help="Enter 0 if this option is not available"),
        'promo_code_elsa': fields.integer('ELSA', required=False, help="Promo code for students member of ELSA."),
        'promo_code': fields.char('Promo code', size=64, required=False, help="Global promo code. Student must enter it in the application form."),
        'promo_code_discount': fields.integer('Promo code discount', required=False, help="Promo code discountl"),
        'promo_code_word_mouth': fields.integer('Word of mouth', required=False),
        'alumni_discount': fields.integer('Alumni Discount', required=False, help="Amount of the alumni discountl"),
        'group_discount': fields.integer('Group Discount', required=False, help="Group Discount for 4 students+"),      
        'note': fields.text('Note'),
        'student_ids': fields.one2many('res.partner', 'product_id', 'Student')	
	}
product_product()
