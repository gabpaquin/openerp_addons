# -*- coding: utf-8 -*-
from osv import fields, osv
import time
from datetime import datetime

#----------------------------------------------------------
# Students
#----------------------------------------------------------

class student_student(osv.osv):
    _name = "res.partner"
    _inherit = "res.partner"
    _description = "School module, student information"
    _columns = {
    'first_name' : fields.char('first name', size=64),
    'last_name' : fields.char('last name', size=64),
		'year': fields.date('Year', size=30),
    'date_of_birth': fields.date('Date of Birth', size=30, required=True),    
		'age': fields.integer('age'),
    'country_of_residence': fields.char('citizenship', size=64),
    'employer_name': fields.char('Employer/University name', size=64),
    'university_major': fields.char('University name', size=64),
		'occupation': fields.selection((('student', 'student'),('professional','professional')),'occupation', required=True),
    'registration_fee': fields.boolean('Registration Fees', required=True, help="Apply only if applicant book more than 5 months in advance."),
    'tuition': fields.integer('Tuition', required=True, help="Tuition for professional"),
    'early_bird': fields.boolean('Early bird date', size=30, required=True),
    'address_type': fields.selection((('home','home address'),
                                      ('office','office address'),
                                      ('study','study address')),
                                      'accomodation' ),
    'accomodation': fields.selection((('single','single room'),
                                      ('double','double room'),
                                      ('no','no room')),
                                      'accomodation' ),
    'full_board': fields.boolean('Full Board'),
    'airport': fields.boolean('Airport pick up'),        
    'extension_weeks': fields.integer('Extension weeks'),
    'extension_weeks_accomodation': fields.selection((('single','single room'),
                                                      ('double','double room'),
                                                      ('no','no room')),
                                                      'Extension weeks accomodation' ),
    'extension_weeks_full_board': fields.boolean('Extension weeks Full Board'),
    'additional_nights': fields.integer('Additional nights'),   
    'additional_nights_accomodation': fields.selection((('single','single room'),
                                                        ('double','double room')),
                                                        'Additional nights accomodation'),
    'hear_about_us': fields.selection((('online','online'),
                                       ('elsa','students member of ELSA'),
                                       ('promo_code','Promotion code')),'Hear about us'),
    'promo_code_elsa': fields.boolean('ELSA', help="Promo code for students member of ELSA."),
    'promo_code': fields.boolean('Promo code', size=64, help="Global promo code. Student must enter it in the application form."),
    'promo_code_discount': fields.integer('Promo code discount', help="Promo code discountl"),
    'promo_code_word_mouth': fields.boolean('Word of mouth'),
    'alumni_discount': fields.boolean('Alumni Discount', help="Amount of the alumni discountl"),
    'group_discount': fields.boolean('Group Discount', help="Group Discount for 4 students+"),      
    'product_id': fields.many2one('product.product', 'school'),	
	}
student_student()
