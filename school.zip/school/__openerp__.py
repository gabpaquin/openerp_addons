{
"name" : "School module",
"version" : "1.0",
"author" : "Gabriel Paquin @ WebAgeCorp",
"website" : "www.webagecorp.com",
"category" : "Generic Modules/Others",
"depends" : ["product", "base", "crm", "base_setup"],
"description" : "School module",
"init_xml" : ["school_view.xml"],
"demo_xml" : [],
"update_xml" : ["student_view.xml", "school_view.xml"],
"auto_install": False,
"installable": True,
"images" : ['images/logo_short.png'],
}



